import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "AMG Dental — Demo Store",
  description: "AMG preview (green/white medical-tech) built from your WooCommerce export."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="header">
          <div className="container">
            <div className="nav">
              <Link href="/" className="brand">
                <span style={{width:10,height:10,borderRadius:999,background:"var(--amg)",display:"inline-block"}} />
                <span>AMG Dental</span>
              </Link>
              <div style={{display:"flex",gap:10,alignItems:"center"}}>
                <span className="badge">Free shipping $400+ • Flat $30 worldwide</span>
                <Link className="btn btnPrimary" href="/family/slactive">Shop</Link>
              </div>
            </div>
          </div>
        </div>
        {children}
        <div className="footer">
          <div className="container">
            © {new Date().getFullYear()} AMG Dental Ltd. • Demo preview (code) • Payments & integrations will be added after design approval.
          </div>
        </div>
      </body>
    </html>
  );
}
