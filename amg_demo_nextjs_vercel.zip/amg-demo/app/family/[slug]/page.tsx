import Link from "next/link";
import products from "../../../data/products.json";

type Product = {
  id: string;
  sku?: string;
  name: string;
  short?: string;
  family: string;
  platform?: string | null;
  diameter?: number;
  length?: number;
  images?: string;
};

function titleFor(slug: string){
  if(slug === "slactive") return "SLActive Implants";
  if(slug === "v7") return "V7 Conical Implants";
  if(slug === "p4") return "P4 Lance Implants";
  if(slug === "multi_unit_kits") return "Multi‑Unit Kits";
  return slug;
}

export default function FamilyPage({ params }: { params: { slug: string } }){
  const slug = params.slug;
  const list = (products as any as Product[]).filter(p => p.family === slug);

  // Build quick filters
  const platforms = Array.from(new Set(list.map(p=>p.platform).filter(Boolean))) as string[];
  const diameters  = Array.from(new Set(list.map(p=>p.diameter).filter(Boolean))).sort((a:any,b:any)=>a-b) as number[];
  const lengths    = Array.from(new Set(list.map(p=>p.length).filter(Boolean))).sort((a:any,b:any)=>a-b) as number[];

  return (
    <main>
      <div className="container">
        <section className="hero" style={{paddingBottom:18}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",gap:12,flexWrap:"wrap"}}>
            <div>
              <h1 className="h1" style={{fontSize:34,marginBottom:10}}>{titleFor(slug)}</h1>
              <p className="p">Live items pulled from your export. Next step: refine naming, images, and family selectors exactly like you want.</p>
            </div>
            <Link className="btn btnGhost" href="/">← Back</Link>
          </div>

          <div className="kpi">
            <span className="pill"><b>{list.length}</b> items</span>
            {platforms.slice(0,6).map(p => <span key={p} className="pill">Platform: {p}</span>)}
            {diameters.length ? <span className="pill">Diameters: {diameters.slice(0,6).join(", ")}{diameters.length>6?"…":""}</span> : null}
            {lengths.length ? <span className="pill">Lengths: {lengths.slice(0,6).join(", ")}{lengths.length>6?"…":""}</span> : null}
          </div>
        </section>

        <section className="section" style={{paddingTop:0}}>
          <div className="list">
            {list.slice(0,90).map(p => (
              <div className="product" key={p.id}>
                <div className="productName">{p.name}</div>
                <div className="meta" style={{marginBottom:10}}>
                  {p.platform ? <span className="tag">{p.platform}</span> : null}
                  {p.diameter ? <span className="tag">Ø {p.diameter}</span> : null}
                  {p.length ? <span className="tag">L {p.length}</span> : null}
                  {p.sku ? <span className="tag">SKU {p.sku}</span> : null}
                </div>
                <Link className="btn btnPrimary" href={`/product/${p.id}`}>View</Link>
              </div>
            ))}
          </div>
          {list.length>90 ? (
            <p className="p" style={{marginTop:14}}>Showing first 90 items for speed. We can add pagination/search next.</p>
          ) : null}
        </section>
      </div>
    </main>
  );
}
