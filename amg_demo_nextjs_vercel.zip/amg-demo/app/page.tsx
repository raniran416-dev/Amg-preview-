import Link from "next/link";
import products from "../data/products.json";

type Product = {
  id: string; name: string; family: string; platform?: string | null; diameter?: number; length?: number;
};

const counts = (products as any as Product[]).reduce((acc:any, p)=>{acc[p.family]=(acc[p.family]||0)+1; return acc;},{});

export default function Home(){
  return (
    <main>
      <div className="container">
        <section className="hero">
          <div className="notice">
            <b>Live code demo generated from your WooCommerce export.</b> This is the starting “template” we’ll style + refine together.
          </div>

          <h1 className="h1" style={{marginTop:18}}>Premium Implant Store Experience — AMG Green & White</h1>
          <p className="p">
            Built for fast B2B ordering: families (V7 / P4 / SLActive) + smart selection flow. Next: login pricing, real cart, Stripe + PayPal.
          </p>

          <div style={{display:"flex",gap:12,marginTop:22,flexWrap:"wrap"}}>
            <Link className="btn btnPrimary" href="/family/slactive">Browse SLActive</Link>
            <Link className="btn btnGhost" href="/family/v7">Browse V7</Link>
            <Link className="btn btnGhost" href="/family/p4">Browse P4</Link>
            <Link className="btn btnGhost" href="/family/multi_unit_kits">Multi‑Unit Kits</Link>
          </div>

          <div className="kpi">
            <span className="pill">SLActive items: {counts.slactive || 0}</span>
            <span className="pill">P4 items: {counts.p4 || 0}</span>
            <span className="pill">V7 items: {counts.v7 || 0}</span>
            <span className="pill">Kits: {counts.multi_unit_kits || 0}</span>
          </div>
        </section>

        <section className="section">
          <h2 className="h2">Families</h2>
          <div className="grid grid3">
            <FamilyCard title="SLActive" desc="Hydrophilic / high‑performance surface line. Fast selection + reorder." href="/family/slactive" />
            <FamilyCard title="V7 Conical" desc="Conical connection line. NP/RP variants as in your catalog." href="/family/v7" />
            <FamilyCard title="P4 Lance" desc="Internal Hex (SP) family with full diameter/length matrix." href="/family/p4" />
          </div>
        </section>
      </div>
    </main>
  )
}

function FamilyCard({title,desc,href}:{title:string;desc:string;href:string}){
  return (
    <div className="card">
      <h3 className="cardTitle">{title}</h3>
      <p className="cardMuted">{desc}</p>
      <div style={{marginTop:14}}>
        <Link className="btn btnPrimary" href={href}>Open</Link>
      </div>
    </div>
  );
}
