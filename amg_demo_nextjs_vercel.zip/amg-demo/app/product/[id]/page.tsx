import Link from "next/link";
import products from "../../../data/products.json";

type Product = {
  id: string;
  sku?: string;
  name: string;
  short?: string;
  family: string;
  platform?: string | null;
  diameter?: number;
  length?: number;
  images?: string;
  categories?: string;
  price?: number | null;
  sale_price?: number | null;
  in_stock?: boolean;
};

export default function ProductPage({ params }: { params: { id: string } }){
  const p = (products as any as Product[]).find(x => String(x.id) === String(params.id));
  if(!p){
    return (
      <main><div className="container" style={{padding:"40px 0"}}>Not found.</div></main>
    );
  }
  const familyHref = `/family/${p.family}`;
  return (
    <main>
      <div className="container">
        <section className="hero" style={{paddingBottom:18}}>
          <Link className="btn btnGhost" href={familyHref}>← Back to family</Link>
          <h1 className="h1" style={{fontSize:30,marginTop:14}}>{p.name}</h1>
          <div className="kpi">
            {p.platform ? <span className="pill">Platform: {p.platform}</span> : null}
            {p.diameter ? <span className="pill">Diameter: {p.diameter}</span> : null}
            {p.length ? <span className="pill">Length: {p.length}</span> : null}
            {p.sku ? <span className="pill">SKU: {p.sku}</span> : null}
          </div>
        </section>

        <section className="section" style={{paddingTop:0}}>
          <div className="grid" style={{gridTemplateColumns:"1.2fr .8fr",gap:16}}>
            <div className="card">
              <h2 className="h2">Overview</h2>
              <p className="p">{p.short || "—"}</p>
              <div style={{marginTop:14}} className="notice">
                Pricing is hidden in this demo. Next step: login-based pricing + real checkout (Stripe + PayPal).
              </div>
            </div>

            <div className="card">
              <h2 className="h2">Order</h2>
              <p className="p" style={{marginBottom:12}}>Login to see price</p>
              <button className="btn btnPrimary" style={{width:"100%"}}>Add to cart</button>
              <div style={{marginTop:10}} className="meta">
                {p.in_stock ? <span className="tag">In stock</span> : <span className="tag">Backorder</span>}
                {p.categories ? <span className="tag">{p.categories.split(",")[0]}</span> : null}
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
